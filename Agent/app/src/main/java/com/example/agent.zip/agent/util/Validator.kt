package com.example.agent.util

//object Validator {
//    fun isValidEmailOrPhone(input: String): Boolean {
//        return input.contains("@") || input.matches(Regex("^1[3-9]\\d{9}$"))
//    }
//
//    fun isValidPassword(password: String): Boolean {
//        return password.length >= 6
//    }
//}
