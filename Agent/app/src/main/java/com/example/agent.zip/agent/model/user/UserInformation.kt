package com.example.agent.model.user

data class UserInformation (
    val emailOrPhone: String = "",
    val password: String = ""
)